# NekoC Windows 便携包 · 532ae2d

此包由提交 `532ae2d` 构建。Windows x64，无需安装 Rust 或 Node.js；需要支持 WebGL2 的 Chrome / Edge。

## 启动

1. 将整个 ZIP 解压到一个固定目录，不要直接在压缩包里运行。
2. 双击 `start-rust-backend.cmd`，保持后端窗口打开。
3. 打开播放器 <http://127.0.0.1:4173/play>，或编辑器 <http://127.0.0.1:4173/>。
4. 导入或拖入自己的 `.bcmkn` / Kitten 4 `.bcm` 文件；`samples/` 内提供示例，包含方块游戏《方界》（fangjie.bcmkn）。

默认端口为 4173；运行前请关闭占用同一端口的旧后端。也可在此目录的终端执行 `web.exe --port 4174`，或者 `web.exe samples/pencraft.bcmkn --port 4173`。

## PICKCAT 扩展

在 `edge://extensions` 或 `chrome://extensions` 开启开发人员模式，选择「加载解压缩的扩展」，指向本包的 `extension/` 目录。

升级时替换完整包，重启后端，并在扩展管理页面点击「重新加载」后刷新作品页。扩展版本仍为 0.1.3，请以本包提交号区分版本。网站登录与播放条件保持不变；尚未直接验证已登录的真实作品页接管。

## 命令行工具

本包包含 `nekoc.exe`，可运行 `nekoc.exe --help` 查看命令。例如：

```powershell
.\nekoc.exe pack .\作品.bcmkn --out .\作品.packed.bcmkn
.\nekoc.exe unpack .\作品.packed.bcmkn --out .\作品.restored.bcmkn
```

打包压缩功能与验证边界见 `docs/pack.md`；当前执行器支持与限制见 `docs/web-studio.md`。`docs/` 中早期审计与性能报告是历史记录，并不代表本包的全量兼容性保证。

## 验证与完整性

- 构建时 `cargo test --all-targets` 295 项、`node --test tests/*.test.mjs` 97 项全部通过。
- `tools/verify-extension-sources.mjs` 使用本包的后端版本通过。
- 版本与二进制信息见 `BUILD-INFO.json`；`SHA256SUMS.txt` 记录包内文件的 SHA-256，压缩包旁另有 `.sha256` 校验文件。

此包不含 Tiny-LM / Qwen 开发内容，也不包含用户的编辑器项目、凭据或缓存。源码仓库：<https://github.com/fttawa/NekoC>。
